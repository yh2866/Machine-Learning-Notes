#Exercise 1: Linear Regression
>Coursera Assignment 1 of linear regression


I have always been fascinated by people - their impromptu, unconditioned actions governed by preconceived perceptions rising from base emotions and past experiences; the innumerous masks that they put on to hide a trivial truth; their insatiable hunger for causes that mean nothing to them. 
This had made me curious if it was possible to understand all the underlying foundations for a person's actions tracing it back to the baser emotions or experiences and whether it was possible to influnce people with crafted experiences which could lead to a possible action in an unforseeable future.


In my quest for understanding people, I quickly concluded that there was no singular governing cause that drives all mankind. Each person is unique in his own way and there can be no generalization in human behaviour. But, there does exist a general structure in which people construct their behaviour and build upon it. So, to see people for what they really are it is important to understand the thought process of people rather than the thoughts itself.

To understand these thought processes, I devised carefully crafted situations and tactfully let myself and my peers get involved in my game without their knowledge while I silently noted down each person's reactions and how they interacted and gained profound knowledge about their most innate proclivities. In due course, I was so consumed in this game that I lost all connection to myself. To truly understand what everyone is going through, I had to involve myself in this game and yet remain unattached to my own emotions so as to remain in full control of my senses. Slowly and steadily, I had detached myself from all worldly emotions. Finally, there came a moment when I realized. 
>Blocking emotions is like wearing an armour. I will be safe from the bullets but I will never feel the breeze. 

There was a wave of understanding that hit me like thunder and I realized I haven't learned anything. When people were reacting to a situation that I created, they were influenced by my thoughts indirectly and as a result all of their actions henceforth was a product of my thought pattern. The true variability and randomness in every person's thought pattern was lost and there was no way to predict their unique thought process as the process had become rigged.
To truly understand someone's thought person, I can't influence them but I need to be influenced by them. Only then can I dwelve into the various unique thought processes in order to gain deep knowledge about them.

Thereby, I set upon a new milestone in my quest where I needed to collect as many minds as I can until I can accurately understand the nature of human thought. I needed to relate to people in the most basest form possible and build up upon them. Sadly, I do not have a very active social life or sibblings whom I can experiment. Naturally, I chose facebook and other social media my means of finding people who can open up to me and I to them so that I can relate to them in the deepest way.

It was no mere coincidence that I found my way amongst female company a lot as girls tend to get very emotional and are looking for someone to open up to and I was a guy looking for people to open up to me. In due course, I became very good at it and I did learn a get deal, no doubt. But this post is not about my findings but rather my psyche and how I dealt with whatever I found.

No sooner than later, I became acquainted with so many different types of psychologies and thought processes that I could relate to new people by fitting them to a psychology from my existing reservoir. Added to this my observational skills and I could tell lot about a person with just one glance. Progressively and with subsequent encounters I could not just tell about a person but I could replicate their entire thought process in my brain. With time, I got so good at it that this replication was nearly flawless and it was like harbouring a new mind in my old brain. I was like mirroring the person who was closest to me. I was so drawn into it that this had become my habbit and I could do this subconsciously until it finally reached to a point when I could no longer control it but rather it controlled me. 

>The painful realization hit me that I had no mind of my own. Like a snake changes skins and moves on to survive, I change personalitites to keep moving. I have become a sum of everyone around me while I lost myself from within me. 

The reaction of people to my uniqueness was something I couldn't fathom. Though, every person immediately related to me when they saw similarities to themselves yet they became very self-aware when the similarities became more vivid and as I became more like a reflection of themselves. It was very disturbing for most of them to see a version of themselves with all the perfection and imperfection that they have but within a different body. People with even a slightly low self esteem could not reconcile to the reality of the reflection that they were seeing in front of them. Finally, in order to save them from themselves, I had to distance myself from them and it was my time to move on. I could have no friends no people with whom I can share my life.

>Was loneliness the price for wisdom?

I am filled with fear of the unknown. I don't know what I have become. Am I good or evil? In my search, have I let myself become something I do not want to face? Can I recover?